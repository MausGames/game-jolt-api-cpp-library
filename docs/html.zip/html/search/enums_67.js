var searchData=
[
  ['gj_5ferror',['GJ_ERROR',['../gj_a_p_i_8h.html#a569dfaf312c729096e9074a6f9ff3d3c',1,'gjAPI.h']]],
  ['gj_5fsort_5fdirection',['GJ_SORT_DIRECTION',['../gj_a_p_i_8h.html#afa59ffb4c840d94088419e1e202294c9',1,'gjAPI.h']]],
  ['gj_5ftrophy_5ftype',['GJ_TROPHY_TYPE',['../gj_a_p_i_8h.html#a3e4b7da70eec6e6ac5f1f92911b6b992',1,'gjAPI.h']]]
];
