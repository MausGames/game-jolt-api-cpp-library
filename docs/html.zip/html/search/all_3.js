var searchData=
[
  ['downloadavatarcall',['DownloadAvatarCall',['../classgj_user.html#ac1f674118e6f16120c2d0fd030188169',1,'gjUser']]],
  ['downloadavatarnow',['DownloadAvatarNow',['../classgj_user.html#ac1186929cdc94143b10e4a99432f58da',1,'gjUser']]],
  ['downloadfile',['DownloadFile',['../classgj_network.html#a6771e678812fc442811d88d12393e363',1,'gjNetwork']]],
  ['downloadfilecall',['DownloadFileCall',['../classgj_a_p_i_1_1gj_inter_file.html#a230d6f3c8384d15e70739aa43088832f',1,'gjAPI::gjInterFile']]],
  ['downloadfilenow',['DownloadFileNow',['../classgj_a_p_i_1_1gj_inter_file.html#a31f5686d6e7c937fb5e68a2dbe36d9a8',1,'gjAPI::gjInterFile']]],
  ['downloadthumbnailcall',['DownloadThumbnailCall',['../classgj_trophy.html#afa1f743a5ec2aa78fbdee0ed2181c0f4',1,'gjTrophy']]],
  ['downloadthumbnailnow',['DownloadThumbnailNow',['../classgj_trophy.html#ae8a475d386ed02a06d43781152249f49',1,'gjTrophy']]]
];
