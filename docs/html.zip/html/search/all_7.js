var searchData=
[
  ['logincall_120',['LoginCall',['../classgj_a_p_i.html#acd58c8af0a28d1cdbdc2bafe83aa84b5',1,'gjAPI::LoginCall(const bool bSession, const std::string &amp;sUserName, const std::string &amp;sUserToken, GJ_NETWORK_OUTPUT(int))'],['../classgj_a_p_i.html#a09c3badb21955c7fa40be454e99ef915',1,'gjAPI::LoginCall(const bool bSession, const std::string &amp;sCredPath, GJ_NETWORK_OUTPUT(int))'],['../classgj_a_p_i.html#a6b9f4ff82bd836270be38a52d26d423f',1,'gjAPI::LoginCall(const bool bSession, GJ_NETWORK_OUTPUT(int))']]],
  ['loginnow_121',['LoginNow',['../classgj_a_p_i.html#a4777f7ed8ebc7449170b74501a3b3ee2',1,'gjAPI::LoginNow(const bool bSession, const std::string &amp;sUserName, const std::string &amp;sUserToken)'],['../classgj_a_p_i.html#aea2db5c2c11e7948c24a3b1e9ecd8f89',1,'gjAPI::LoginNow(const bool bSession, const std::string &amp;sCredPath)'],['../classgj_a_p_i.html#a1327e41bdc1b986e9564709cf8de95f7',1,'gjAPI::LoginNow(const bool bSession)']]],
  ['logout_122',['Logout',['../classgj_a_p_i.html#aad97f542f7a5104e508920b669f0b38c',1,'gjAPI']]]
];
