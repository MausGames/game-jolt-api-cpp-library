var searchData=
[
  ['safe_5fdelete',['SAFE_DELETE',['../gj_a_p_i_8h.html#a9bbcd82e77c41df827c09759def05c9a',1,'gjAPI.h']]],
  ['safe_5fdelete_5farray',['SAFE_DELETE_ARRAY',['../gj_a_p_i_8h.html#a506b3685b3eb05aac751f9e14cbed93b',1,'gjAPI.h']]],
  ['safe_5fmap_5fget',['SAFE_MAP_GET',['../gj_a_p_i_8h.html#aeb4171b9db85ae8fc204fc75845193db',1,'gjAPI.h']]]
];
