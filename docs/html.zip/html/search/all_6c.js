var searchData=
[
  ['login',['Login',['../classgj_a_p_i.html#aeac7576cc5a5c2ed1a98e9d287df08f6',1,'gjAPI::Login(const bool bSession, const std::string &amp;sUserName, const std::string &amp;sUserToken)'],['../classgj_a_p_i.html#a7e112c02f08df84280329f1d159070e4',1,'gjAPI::Login(const bool bSession, std::string sCredPath=GJ_API_CRED)']]],
  ['logout',['Logout',['../classgj_a_p_i.html#aad97f542f7a5104e508920b669f0b38c',1,'gjAPI']]]
];
