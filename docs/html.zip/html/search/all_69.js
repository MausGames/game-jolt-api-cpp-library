var searchData=
[
  ['interdatastoreglobal',['InterDataStoreGlobal',['../classgj_a_p_i.html#af727e25b9916b44c1125274900b733c9',1,'gjAPI']]],
  ['interdatastoreuser',['InterDataStoreUser',['../classgj_a_p_i.html#ad11720c8771e4c90bef596a034f9ad02',1,'gjAPI']]],
  ['interfile',['InterFile',['../classgj_a_p_i.html#aac872be90c65c09a33de5d16c8a373fb',1,'gjAPI']]],
  ['interscore',['InterScore',['../classgj_a_p_i.html#a48853a472907b2c8640106ce04e2b736',1,'gjAPI']]],
  ['intertrophy',['InterTrophy',['../classgj_a_p_i.html#aa730f2b0648d468d94b63b8c3c1c3257',1,'gjAPI']]],
  ['interuser',['InterUser',['../classgj_a_p_i.html#ac0635ccbe2a725502c5bb755ffd459cd',1,'gjAPI']]],
  ['isachieved',['IsAchieved',['../classgj_trophy.html#adc4b33f60e1dd2b4db7f9f26c5328279',1,'gjTrophy']]],
  ['isactive',['IsActive',['../classgj_a_p_i.html#a3fb156d31fc69df240f0d9ef9da1699c',1,'gjAPI']]],
  ['isconnected',['IsConnected',['../classgj_a_p_i.html#ab491554cff8f3686c9a9eea19cf3fed8',1,'gjAPI']]],
  ['isguest',['IsGuest',['../classgj_score.html#a7ccafa9bda3358bf37f9451d3ca8bad3',1,'gjScore']]],
  ['isprimary',['IsPrimary',['../classgj_score_table.html#ad707ef9229771528d819c04287501cf4',1,'gjScoreTable']]]
];
