var searchData=
[
  ['gj_5ffile_5ferror',['GJ_FILE_ERROR',['../gj_a_p_i_8h.html#a2c0031b2b9ebf4d8d29b2284b515f655aa2cb87e958118c9751a4adffd67dcd4e',1,'gjAPI.h']]],
  ['gj_5finvalid_5fcall',['GJ_INVALID_CALL',['../gj_a_p_i_8h.html#a2c0031b2b9ebf4d8d29b2284b515f655ab746ed1aba9968bf0a55f81b5b8c8335',1,'gjAPI.h']]],
  ['gj_5finvalid_5finput',['GJ_INVALID_INPUT',['../gj_a_p_i_8h.html#a2c0031b2b9ebf4d8d29b2284b515f655a8a270eee11cdc3db8005fbbc75ea72fc',1,'gjAPI.h']]],
  ['gj_5fnetwork_5ferror',['GJ_NETWORK_ERROR',['../gj_a_p_i_8h.html#a2c0031b2b9ebf4d8d29b2284b515f655a2c8183f55dacf8fdc2d6dd65868d857e',1,'gjAPI.h']]],
  ['gj_5fno_5fdata_5ffound',['GJ_NO_DATA_FOUND',['../gj_a_p_i_8h.html#a2c0031b2b9ebf4d8d29b2284b515f655a550df7f58e4657f87b40070f4b53e8ef',1,'gjAPI.h']]],
  ['gj_5fnot_5fconnected',['GJ_NOT_CONNECTED',['../gj_a_p_i_8h.html#a2c0031b2b9ebf4d8d29b2284b515f655a160a15ee496b8d0d82e46f627a06db0b',1,'gjAPI.h']]],
  ['gj_5fok',['GJ_OK',['../gj_a_p_i_8h.html#a2c0031b2b9ebf4d8d29b2284b515f655a08b8a3ba72994c4f82e31545db9509b7',1,'gjAPI.h']]],
  ['gj_5frequest_5fcanceled',['GJ_REQUEST_CANCELED',['../gj_a_p_i_8h.html#a2c0031b2b9ebf4d8d29b2284b515f655a34f03b8b6b2ed5f5637353ea426e5cba',1,'gjAPI.h']]],
  ['gj_5frequest_5ffailed',['GJ_REQUEST_FAILED',['../gj_a_p_i_8h.html#a2c0031b2b9ebf4d8d29b2284b515f655a69fd1ff49d476a1172d45b37f9b5b631',1,'gjAPI.h']]],
  ['gj_5fsort_5fasc',['GJ_SORT_ASC',['../gj_a_p_i_8h.html#a630008446996c41f14de9918745c4bd7a216e2cee5928b50c5f5de1c5a732935b',1,'gjAPI.h']]],
  ['gj_5fsort_5fdesc',['GJ_SORT_DESC',['../gj_a_p_i_8h.html#a630008446996c41f14de9918745c4bd7a6a739e18bb5a00704f64a276944da838',1,'gjAPI.h']]],
  ['gj_5fsort_5fundef',['GJ_SORT_UNDEF',['../gj_a_p_i_8h.html#a630008446996c41f14de9918745c4bd7aa25af730a12bcffa9c5da0b4e07b96d0',1,'gjAPI.h']]],
  ['gj_5ftrophy_5fachieved',['GJ_TROPHY_ACHIEVED',['../gj_a_p_i_8h.html#a2062cb01cf41404519c2a10cbbe5326cadd20030f438117ee947374ee77be2361',1,'gjAPI.h']]],
  ['gj_5ftrophy_5fall',['GJ_TROPHY_ALL',['../gj_a_p_i_8h.html#a2062cb01cf41404519c2a10cbbe5326cac0fcc42d78aa6cb110d66eae47032b12',1,'gjAPI.h']]],
  ['gj_5ftrophy_5fnot_5fachieved',['GJ_TROPHY_NOT_ACHIEVED',['../gj_a_p_i_8h.html#a2062cb01cf41404519c2a10cbbe5326ca0e603c954c86816f3217e73658966e4b',1,'gjAPI.h']]]
];
