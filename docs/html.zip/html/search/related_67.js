var searchData=
[
  ['gjapi',['gjAPI',['../classgj_trophy.html#ae3511a375ac2c886310a17f8dc0cf770',1,'gjTrophy::gjAPI()'],['../classgj_user.html#ae3511a375ac2c886310a17f8dc0cf770',1,'gjUser::gjAPI()']]]
];
