var searchData=
[
  ['isachieved',['IsAchieved',['../classgj_trophy.html#adc4b33f60e1dd2b4db7f9f26c5328279',1,'gjTrophy']]],
  ['isguest',['IsGuest',['../classgj_score.html#a7ccafa9bda3358bf37f9451d3ca8bad3',1,'gjScore']]],
  ['isprimary',['IsPrimary',['../classgj_score_table.html#ad707ef9229771528d819c04287501cf4',1,'gjScoreTable']]],
  ['issecret',['IsSecret',['../classgj_trophy.html#a5b58ccac18a8b5c9c4a7df4c7cbb09b2',1,'gjTrophy']]],
  ['issessionactive',['IsSessionActive',['../classgj_a_p_i.html#a085411f8b0a9c9b434e5a4ec2095cf8a',1,'gjAPI']]],
  ['isuserconnected',['IsUserConnected',['../classgj_a_p_i.html#a80ed949b51cd62e7ab90a8162bf0cade',1,'gjAPI']]]
];
