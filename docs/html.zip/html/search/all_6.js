var searchData=
[
  ['init_113',['Init',['../classgj_a_p_i.html#a8d0fdb914b11837984990091601ea028',1,'gjAPI']]],
  ['isachieved_114',['IsAchieved',['../classgj_trophy.html#a8c0090795ecc90cba59098424fb23ff1',1,'gjTrophy']]],
  ['isguest_115',['IsGuest',['../classgj_score.html#abad0da04f2afbb20d07e16ae85f3bb6a',1,'gjScore']]],
  ['isprimary_116',['IsPrimary',['../classgj_score_table.html#a2bc9a73f9f16d2456d8cd8a52eede1c7',1,'gjScoreTable']]],
  ['issecret_117',['IsSecret',['../classgj_trophy.html#a76fbeebaba13d418de15f7163d42f996',1,'gjTrophy']]],
  ['issessionactive_118',['IsSessionActive',['../classgj_a_p_i.html#a2dd8e13db0c2500caa019405b6816dd2',1,'gjAPI']]],
  ['isuserconnected_119',['IsUserConnected',['../classgj_a_p_i.html#a3d7347d5c4114a97922806729c0b7fbd',1,'gjAPI']]]
];
