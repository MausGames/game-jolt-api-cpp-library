var searchData=
[
  ['null',['Null',['../classgj_a_p_i.html#adf35349961f9542ec6f01235562f0cf8',1,'gjAPI::Null(const std::string &amp;sData, void *pAdd, std::string *psOutput)'],['../classgj_a_p_i.html#aae0d10707cd5ed993e123b9f2d7db25a',1,'gjAPI::Null(const D &amp;pObject, void *pData)']]]
];
