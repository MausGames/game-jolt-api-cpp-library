var searchData=
[
  ['isactive',['IsActive',['../classgj_a_p_i.html#a3fb156d31fc69df240f0d9ef9da1699c',1,'gjAPI']]],
  ['isconnected',['IsConnected',['../classgj_a_p_i.html#ab491554cff8f3686c9a9eea19cf3fed8',1,'gjAPI']]],
  ['isguest',['IsGuest',['../classgj_score.html#a7ccafa9bda3358bf37f9451d3ca8bad3',1,'gjScore']]],
  ['isprimary',['IsPrimary',['../classgj_score_table.html#ad707ef9229771528d819c04287501cf4',1,'gjScoreTable']]]
];
