var searchData=
[
  ['fetchdataitemscall',['FetchDataItemsCall',['../classgj_a_p_i_1_1gj_inter_data_store.html#a3e4715425f169fd9ccfecf0eb4e1db2e',1,'gjAPI::gjInterDataStore']]],
  ['fetchdataitemsnow',['FetchDataItemsNow',['../classgj_a_p_i_1_1gj_inter_data_store.html#a34c115bf247c740a6bbd15c061342e96',1,'gjAPI::gjInterDataStore']]],
  ['fetchscorescall',['FetchScoresCall',['../classgj_score_table.html#a3051a3baeb767adb7a0f7a24f2780ef6',1,'gjScoreTable']]],
  ['fetchscoresnow',['FetchScoresNow',['../classgj_score_table.html#aeaee931a5c49f2a7401ae464bc746f34',1,'gjScoreTable']]],
  ['fetchscoretablescall',['FetchScoreTablesCall',['../classgj_a_p_i_1_1gj_inter_score.html#ac48da1ac4ee72bd0a887d56dbb3b058f',1,'gjAPI::gjInterScore']]],
  ['fetchscoretablesnow',['FetchScoreTablesNow',['../classgj_a_p_i_1_1gj_inter_score.html#a39ae5f33794f2982bdf39c3cff3f791a',1,'gjAPI::gjInterScore']]],
  ['fetchtrophiescall',['FetchTrophiesCall',['../classgj_a_p_i_1_1gj_inter_trophy.html#ad3cbf66742dbdcd45e117ae03db05063',1,'gjAPI::gjInterTrophy']]],
  ['fetchtrophiesnow',['FetchTrophiesNow',['../classgj_a_p_i_1_1gj_inter_trophy.html#a87cd4ee7c9f85ef86cabdce092e2e4a0',1,'gjAPI::gjInterTrophy']]],
  ['fetchusercall',['FetchUserCall',['../classgj_a_p_i_1_1gj_inter_user.html#af2683d5e8dfe8bd86a14b7acde8937b6',1,'gjAPI::gjInterUser::FetchUserCall(const int &amp;iID, GJ_NETWORK_OUTPUT(gjUserPtr))'],['../classgj_a_p_i_1_1gj_inter_user.html#a5edca2d3a7ebafc3622b7f3a9d341860',1,'gjAPI::gjInterUser::FetchUserCall(const std::string &amp;sName, GJ_NETWORK_OUTPUT(gjUserPtr))'],['../classgj_score.html#a69871549e24dfd6a49d510dc0e3971b2',1,'gjScore::FetchUserCall()']]],
  ['fetchusernow',['FetchUserNow',['../classgj_a_p_i_1_1gj_inter_user.html#ae2eb7be0240d96b5c34357024dea595f',1,'gjAPI::gjInterUser::FetchUserNow(const int &amp;iID, gjUserPtr *ppOutput)'],['../classgj_a_p_i_1_1gj_inter_user.html#a8c6f7e22a6379b817da42debf4c63f35',1,'gjAPI::gjInterUser::FetchUserNow(const std::string &amp;sName, gjUserPtr *ppOutput)'],['../classgj_score.html#aa52aafa8d68282c0c7b4f16f063e2280',1,'gjScore::FetchUserNow()']]],
  ['finish',['Finish',['../classgj_network_1_1gj_call.html#af48d74d349b32def2837aa35e534ce80',1,'gjNetwork::gjCall::Finish()'],['../classgj_network_1_1gj_call_request.html#abc1cdd44384d6c54e613c3db82ba6002',1,'gjNetwork::gjCallRequest::Finish()'],['../classgj_network_1_1gj_call_download.html#aa3aeecf984e193375de71a10febd7751',1,'gjNetwork::gjCallDownload::Finish()']]]
];
