var searchData=
[
  ['logincall',['LoginCall',['../classgj_a_p_i.html#a549dc5581e79f2f156ca519fb50b2715',1,'gjAPI::LoginCall(const bool &amp;bSession, const std::string &amp;sUserName, const std::string &amp;sUserToken, GJ_NETWORK_OUTPUT(int))'],['../classgj_a_p_i.html#a3f0f0c8e17bdfd163d73ee6c5a5981c3',1,'gjAPI::LoginCall(const bool &amp;bSession, const std::string &amp;sCredPath, GJ_NETWORK_OUTPUT(int))'],['../classgj_a_p_i.html#a135a6c747e1f45eb49d3f0d97e392058',1,'gjAPI::LoginCall(const bool &amp;bSession, GJ_NETWORK_OUTPUT(int))']]],
  ['loginnow',['LoginNow',['../classgj_a_p_i.html#a6980051dd0b5da4d842beefbaafaa90c',1,'gjAPI::LoginNow(const bool &amp;bSession, const std::string &amp;sUserName, const std::string &amp;sUserToken)'],['../classgj_a_p_i.html#a6db5fb5eb5dbead9853ca9d40722883a',1,'gjAPI::LoginNow(const bool &amp;bSession, const std::string &amp;sCredPath)'],['../classgj_a_p_i.html#a7b83c422b24adbeec07b2a48584ffa7d',1,'gjAPI::LoginNow(const bool &amp;bSession)']]],
  ['logout',['Logout',['../classgj_a_p_i.html#aad97f542f7a5104e508920b669f0b38c',1,'gjAPI']]]
];
