var searchData=
[
  ['s_5faslog_203',['s_asLog',['../classgj_a_p_i.html#a4350b5be5b88a8377fdd560222d2860b',1,'gjAPI']]],
  ['s_5fpprimary_204',['s_pPrimary',['../classgj_score_table.html#a40773bb3ea0edaa3b42ba49938fdb013',1,'gjScoreTable']]],
  ['sendrequest_205',['SendRequest',['../classgj_a_p_i.html#a5d515fcc1171dbf4c78705d081eebd17',1,'gjAPI::SendRequest()'],['../classgj_network.html#a028a06a7c0e3b7657f9d7085a53763ba',1,'gjNetwork::SendRequest()']]],
  ['sendrequestcall_206',['SendRequestCall',['../classgj_a_p_i.html#adf1f69d7584bc029e742426d75065ad1',1,'gjAPI::SendRequestCall(const std::string &amp;sURL, GJ_NETWORK_OUTPUT(D))'],['../classgj_a_p_i.html#a0716dbbcbcb2d09f5e24976a58c874e6',1,'gjAPI::SendRequestCall(const std::string &amp;sURL, GJ_NETWORK_PROCESS, GJ_NETWORK_OUTPUT(D))']]],
  ['sendrequestnow_207',['SendRequestNow',['../classgj_a_p_i.html#ab438b835dbf55021d926907111b90561',1,'gjAPI']]],
  ['setdatabase64call_208',['SetDataBase64Call',['../classgj_data_item.html#ae3ed0a609ef410672783ce4c74107721',1,'gjDataItem::SetDataBase64Call(void *pData, const size_t iSize)'],['../classgj_data_item.html#ac87603cae241b71fc3298c2588bbd157',1,'gjDataItem::SetDataBase64Call(void *pData, const size_t iSize, GJ_NETWORK_OUTPUT(gjDataItemPtr))']]],
  ['setdatabase64now_209',['SetDataBase64Now',['../classgj_data_item.html#acebac4a13bdc2dbaf06fcfc533a2374f',1,'gjDataItem']]],
  ['setdatacall_210',['SetDataCall',['../classgj_data_item.html#ae9c6e7b12cb64e71210fb84743210f8d',1,'gjDataItem::SetDataCall(const std::string &amp;sData, GJ_NETWORK_OUTPUT(gjDataItemPtr))'],['../classgj_data_item.html#aa391e5c723ed4753e3d625b53e073504',1,'gjDataItem::SetDataCall(const std::string &amp;sData)']]],
  ['setdatanow_211',['SetDataNow',['../classgj_data_item.html#afa73a0ef00f8eeb42a357d9c280b6498',1,'gjDataItem']]],
  ['sethidden_212',['SetHidden',['../classgj_a_p_i_1_1gj_inter_trophy.html#aba77d808dcfacccafa304073233a0510',1,'gjAPI::gjInterTrophy']]],
  ['setsecret_213',['SetSecret',['../classgj_a_p_i_1_1gj_inter_trophy.html#af415f8aa6da8e7ea13b281e9fd426449',1,'gjAPI::gjInterTrophy']]],
  ['setsessionactive_214',['SetSessionActive',['../classgj_a_p_i.html#a23e0eab1f96cdc1c99e9511e7d682d26',1,'gjAPI']]],
  ['setsort_215',['SetSort',['../classgj_a_p_i_1_1gj_inter_trophy.html#a070757b4a47a8c5f047428606f16f136',1,'gjAPI::gjInterTrophy']]],
  ['soutput_216',['sOutput',['../structgj_network_1_1gj_call_template_1_1s_output.html',1,'gjNetwork::gjCallTemplate']]],
  ['soutput_3c_20d_20_3e_217',['sOutput&lt; D &gt;',['../structgj_network_1_1gj_call_template_1_1s_output.html',1,'gjNetwork::gjCallTemplate']]],
  ['soutputspecific_218',['sOutputSpecific',['../structgj_network_1_1gj_call_template_1_1s_output_specific.html',1,'gjNetwork::gjCallTemplate']]]
];
