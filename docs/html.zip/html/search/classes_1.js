var searchData=
[
  ['soutput',['sOutput',['../structgj_network_1_1gj_call_template_1_1s_output.html',1,'gjNetwork::gjCallTemplate']]],
  ['soutputspecific',['sOutputSpecific',['../structgj_network_1_1gj_call_template_1_1s_output_specific.html',1,'gjNetwork::gjCallTemplate']]]
];
