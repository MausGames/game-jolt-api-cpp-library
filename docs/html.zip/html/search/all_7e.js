var searchData=
[
  ['_7egjapi',['~gjAPI',['../classgj_a_p_i.html#a6a7ab260cd1e5bf427b86581fd923cd2',1,'gjAPI']]],
  ['_7egjcall',['~gjCall',['../classgj_network_1_1gj_call.html#ace552a6ae520937d2f7e9feca203e1ea',1,'gjNetwork::gjCall']]],
  ['_7egjcalltemplate',['~gjCallTemplate',['../classgj_network_1_1gj_call_template.html#af016c767d6eed8a5259c405a7d872c24',1,'gjNetwork::gjCallTemplate']]],
  ['_7egjinterdatastore',['~gjInterDataStore',['../classgj_a_p_i_1_1gj_inter_data_store.html#a19427eb0866fcbaa308003c1f2f10747',1,'gjAPI::gjInterDataStore']]],
  ['_7egjinterfile',['~gjInterFile',['../classgj_a_p_i_1_1gj_inter_file.html#a17b502b6d59918944a37ca950f97fdef',1,'gjAPI::gjInterFile']]],
  ['_7egjinterscore',['~gjInterScore',['../classgj_a_p_i_1_1gj_inter_score.html#a03f925451fce99b11df7c5e9548ab318',1,'gjAPI::gjInterScore']]],
  ['_7egjintertrophy',['~gjInterTrophy',['../classgj_a_p_i_1_1gj_inter_trophy.html#af5aed24a29b6d19aa5b546a76b1ef90b',1,'gjAPI::gjInterTrophy']]],
  ['_7egjinteruser',['~gjInterUser',['../classgj_a_p_i_1_1gj_inter_user.html#aa5c41caf9c859422320569aaa28d4936',1,'gjAPI::gjInterUser']]],
  ['_7egjnetwork',['~gjNetwork',['../classgj_network.html#a907373706b7dfc9ae201af9bc5cec2f7',1,'gjNetwork']]],
  ['_7egjscoretable',['~gjScoreTable',['../classgj_score_table.html#a80f3f9631690638b65235a86762c6176',1,'gjScoreTable']]]
];
