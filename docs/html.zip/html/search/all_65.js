var searchData=
[
  ['errorlogadd',['ErrorLogAdd',['../classgj_a_p_i.html#af4d06e9ef4d355259fde6213abc6a117',1,'gjAPI']]],
  ['errorlogget',['ErrorLogGet',['../classgj_a_p_i.html#a478dd3f7b6bfc10e3919851563a0af1a',1,'gjAPI']]],
  ['errorlogreset',['ErrorLogReset',['../classgj_a_p_i.html#ab217859b75a3e86495af9743143089f8',1,'gjAPI']]]
];
