var searchData=
[
  ['s_5faslog',['s_asLog',['../classgj_a_p_i.html#a4350b5be5b88a8377fdd560222d2860b',1,'gjAPI']]],
  ['s_5fpprimary',['s_pPrimary',['../classgj_score_table.html#a40773bb3ea0edaa3b42ba49938fdb013',1,'gjScoreTable']]]
];
