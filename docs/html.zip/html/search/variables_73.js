var searchData=
[
  ['s_5fpprimary',['s_pPrimary',['../classgj_score_table.html#a40773bb3ea0edaa3b42ba49938fdb013',1,'gjScoreTable']]]
];
