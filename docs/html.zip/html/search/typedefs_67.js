var searchData=
[
  ['gjdata',['gjData',['../gj_a_p_i_8h.html#aad290eedbab4c477ef3ff2467ce58f19',1,'gjAPI.h']]],
  ['gjdataitemmap',['gjDataItemMap',['../gj_a_p_i_8h.html#a8e43835c88ba3905a5664e32a3aefb3c',1,'gjAPI.h']]],
  ['gjdataitemptr',['gjDataItemPtr',['../gj_a_p_i_8h.html#a1652182a47c89dd9bc22f9d59a75c421',1,'gjAPI.h']]],
  ['gjdatalist',['gjDataList',['../gj_a_p_i_8h.html#ab04a6c830d54bc78dc35620bb785f6c4',1,'gjAPI.h']]],
  ['gjscorelist',['gjScoreList',['../gj_a_p_i_8h.html#ad6a7d7dc7b05b4fbb6bd388b61830273',1,'gjAPI.h']]],
  ['gjscoreptr',['gjScorePtr',['../gj_a_p_i_8h.html#a8f4c79c1e7fbc1b977c07b03140dbeb4',1,'gjAPI.h']]],
  ['gjscoretablemap',['gjScoreTableMap',['../gj_a_p_i_8h.html#a069b27e76fb8228af50f69188dea355a',1,'gjAPI.h']]],
  ['gjtrophylist',['gjTrophyList',['../gj_a_p_i_8h.html#ac0a7c6a0486007c7f67a14b9dda52c3d',1,'gjAPI.h']]],
  ['gjtrophyptr',['gjTrophyPtr',['../gj_a_p_i_8h.html#a3f726361e31d8712ae32a9e121ae014a',1,'gjAPI.h']]],
  ['gjuserptr',['gjUserPtr',['../gj_a_p_i_8h.html#a92c7d503fa3b4a1202b1b6e977cc6fb0',1,'gjAPI.h']]],
  ['gjvoidptr',['gjVoidPtr',['../gj_a_p_i_8h.html#a666e36b4560209b63bef96d3c03352bc',1,'gjAPI.h']]]
];
