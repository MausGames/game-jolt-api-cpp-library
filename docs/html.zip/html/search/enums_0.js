var searchData=
[
  ['gj_5ferror_426',['GJ_ERROR',['../gj_a_p_i_8h.html#a2c0031b2b9ebf4d8d29b2284b515f655',1,'gjAPI.h']]],
  ['gj_5fsort_5fdirection_427',['GJ_SORT_DIRECTION',['../gj_a_p_i_8h.html#a630008446996c41f14de9918745c4bd7',1,'gjAPI.h']]],
  ['gj_5ftrophy_5ftype_428',['GJ_TROPHY_TYPE',['../gj_a_p_i_8h.html#a2062cb01cf41404519c2a10cbbe5326c',1,'gjAPI.h']]]
];
