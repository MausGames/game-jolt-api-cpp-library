var searchData=
[
  ['update_219',['Update',['../classgj_a_p_i.html#a83f15c48184e1abc3220b0752b4fd21c',1,'gjAPI::Update()'],['../classgj_network.html#a00dc4fd498666c8b4a0211d8bc84407b',1,'gjNetwork::Update()']]],
  ['update_20notes_220',['Update Notes',['../update_notes.html',1,'']]],
  ['updatedatacall_221',['UpdateDataCall',['../classgj_trophy.html#a554fceba681bd471afcbd4e8e7f98d65',1,'gjTrophy::UpdateDataCall()'],['../classgj_trophy.html#a55182e484eada432553acc57da048087',1,'gjTrophy::UpdateDataCall(GJ_NETWORK_OUTPUT(gjTrophyPtr))'],['../classgj_user.html#a8a5551b9e03be1e407f226ad086fedc3',1,'gjUser::UpdateDataCall()'],['../classgj_user.html#a0a9bc8dffb339f6eacb01c186019a939',1,'gjUser::UpdateDataCall(GJ_NETWORK_OUTPUT(gjUserPtr))']]],
  ['updatedatanow_222',['UpdateDataNow',['../classgj_trophy.html#a3f9973c75b5e254e7f13dd80fb80317c',1,'gjTrophy::UpdateDataNow()'],['../classgj_user.html#a19b24171c262f8bfb5ecf31dc5d8caed',1,'gjUser::UpdateDataNow()']]]
];
