var searchData=
[
  ['fetchdataitemscall_263',['FetchDataItemsCall',['../classgj_a_p_i_1_1gj_inter_data_store.html#a3e4715425f169fd9ccfecf0eb4e1db2e',1,'gjAPI::gjInterDataStore']]],
  ['fetchdataitemsnow_264',['FetchDataItemsNow',['../classgj_a_p_i_1_1gj_inter_data_store.html#a34c115bf247c740a6bbd15c061342e96',1,'gjAPI::gjInterDataStore']]],
  ['fetchscorescall_265',['FetchScoresCall',['../classgj_score_table.html#a1c98ac66164ff1f4bd2108e495680adb',1,'gjScoreTable']]],
  ['fetchscoresnow_266',['FetchScoresNow',['../classgj_score_table.html#ab7ed423d58d4384493ffe0bf990aaf18',1,'gjScoreTable']]],
  ['fetchscoretablescall_267',['FetchScoreTablesCall',['../classgj_a_p_i_1_1gj_inter_score.html#ac48da1ac4ee72bd0a887d56dbb3b058f',1,'gjAPI::gjInterScore']]],
  ['fetchscoretablesnow_268',['FetchScoreTablesNow',['../classgj_a_p_i_1_1gj_inter_score.html#a39ae5f33794f2982bdf39c3cff3f791a',1,'gjAPI::gjInterScore']]],
  ['fetchtrophiescall_269',['FetchTrophiesCall',['../classgj_a_p_i_1_1gj_inter_trophy.html#a62768f637954e4272c3d66e2bbea4cdf',1,'gjAPI::gjInterTrophy']]],
  ['fetchtrophiesnow_270',['FetchTrophiesNow',['../classgj_a_p_i_1_1gj_inter_trophy.html#a4c524434529936ce99e6cd4e6960c7eb',1,'gjAPI::gjInterTrophy']]],
  ['fetchusercall_271',['FetchUserCall',['../classgj_a_p_i_1_1gj_inter_user.html#ae91fff1a50be47b7a2ebdb61dbb463be',1,'gjAPI::gjInterUser::FetchUserCall(const int iID, GJ_NETWORK_OUTPUT(gjUserPtr))'],['../classgj_a_p_i_1_1gj_inter_user.html#a5edca2d3a7ebafc3622b7f3a9d341860',1,'gjAPI::gjInterUser::FetchUserCall(const std::string &amp;sName, GJ_NETWORK_OUTPUT(gjUserPtr))'],['../classgj_score.html#a69871549e24dfd6a49d510dc0e3971b2',1,'gjScore::FetchUserCall()']]],
  ['fetchusernow_272',['FetchUserNow',['../classgj_a_p_i_1_1gj_inter_user.html#a47923d5799e9e5770f7aa559db1d7e80',1,'gjAPI::gjInterUser::FetchUserNow(const int iID, gjUserPtr *ppOutput)'],['../classgj_a_p_i_1_1gj_inter_user.html#a8c6f7e22a6379b817da42debf4c63f35',1,'gjAPI::gjInterUser::FetchUserNow(const std::string &amp;sName, gjUserPtr *ppOutput)'],['../classgj_score.html#aa52aafa8d68282c0c7b4f16f063e2280',1,'gjScore::FetchUserNow()']]]
];
