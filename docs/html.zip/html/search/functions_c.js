var searchData=
[
  ['removecall',['RemoveCall',['../classgj_data_item.html#ae35a5f2447345d3984844da5a65223da',1,'gjDataItem::RemoveCall()'],['../classgj_data_item.html#a4ab47691b87a414e4a837d1acd732c16',1,'gjDataItem::RemoveCall(GJ_NETWORK_OUTPUT(gjDataItemPtr))']]],
  ['removenow',['RemoveNow',['../classgj_data_item.html#a43f4827f3eccc13fb0f92142ca8d722d',1,'gjDataItem']]],
  ['reserve',['reserve',['../classgj_lookup.html#a8a69e6d5b35b29d3a27ec14c274ac8b2',1,'gjLookup']]]
];
