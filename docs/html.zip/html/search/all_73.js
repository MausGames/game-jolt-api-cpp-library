var searchData=
[
  ['s_5fpprimary',['s_pPrimary',['../classgj_score_table.html#a40773bb3ea0edaa3b42ba49938fdb013',1,'gjScoreTable']]],
  ['safe_5fdelete',['SAFE_DELETE',['../gj_a_p_i_8h.html#a9bbcd82e77c41df827c09759def05c9a',1,'gjAPI.h']]],
  ['safe_5fdelete_5farray',['SAFE_DELETE_ARRAY',['../gj_a_p_i_8h.html#a506b3685b3eb05aac751f9e14cbed93b',1,'gjAPI.h']]],
  ['safe_5fmap_5fget',['SAFE_MAP_GET',['../gj_a_p_i_8h.html#aeb4171b9db85ae8fc204fc75845193db',1,'gjAPI.h']]],
  ['sendrequest',['SendRequest',['../classgj_a_p_i.html#a5d515fcc1171dbf4c78705d081eebd17',1,'gjAPI::SendRequest()'],['../classgj_network.html#a4d95134574cd681e0efb0596a56f1341',1,'gjNetwork::SendRequest()']]],
  ['sendrequestcall',['SendRequestCall',['../classgj_a_p_i.html#a0716dbbcbcb2d09f5e24976a58c874e6',1,'gjAPI']]],
  ['sendrequestnow',['SendRequestNow',['../classgj_a_p_i.html#ab438b835dbf55021d926907111b90561',1,'gjAPI']]],
  ['setdatabase64call',['SetDataBase64Call',['../classgj_data_item.html#aab176198a3ad8f52ad8dfc5b9c70c246',1,'gjDataItem::SetDataBase64Call(void *pData, const size_t &amp;iSize)'],['../classgj_data_item.html#a890d37878d98e103b2130d72e930181d',1,'gjDataItem::SetDataBase64Call(void *pData, const size_t &amp;iSize, GJ_NETWORK_OUTPUT(gjDataItemPtr))']]],
  ['setdatabase64now',['SetDataBase64Now',['../classgj_data_item.html#aee6aa0a81f314657205068fc3aba38a5',1,'gjDataItem']]],
  ['setdatacall',['SetDataCall',['../classgj_data_item.html#aa391e5c723ed4753e3d625b53e073504',1,'gjDataItem::SetDataCall(const std::string &amp;sData)'],['../classgj_data_item.html#ae9c6e7b12cb64e71210fb84743210f8d',1,'gjDataItem::SetDataCall(const std::string &amp;sData, GJ_NETWORK_OUTPUT(gjDataItemPtr))']]],
  ['setdatanow',['SetDataNow',['../classgj_data_item.html#afa73a0ef00f8eeb42a357d9c280b6498',1,'gjDataItem']]],
  ['setsession',['SetSession',['../classgj_a_p_i.html#a476790bd88b46197af741e1c3415365c',1,'gjAPI']]],
  ['sortascending',['SortAscending',['../gj_score_8cpp.html#aa5b95eca9001988ee00efb0b614c79b9',1,'SortAscending(const gjScore *i, const gjScore *j):&#160;gjScore.cpp'],['../gj_score_8h.html#aa5b95eca9001988ee00efb0b614c79b9',1,'SortAscending(const gjScore *i, const gjScore *j):&#160;gjScore.cpp']]],
  ['sortdescending',['SortDescending',['../gj_score_8cpp.html#a164a53766b45fc8044986340559b26c7',1,'SortDescending(const gjScore *i, const gjScore *j):&#160;gjScore.cpp'],['../gj_score_8h.html#a164a53766b45fc8044986340559b26c7',1,'SortDescending(const gjScore *i, const gjScore *j):&#160;gjScore.cpp']]],
  ['soutput',['sOutput',['../structgj_network_1_1gj_call_template_1_1s_output.html',1,'gjNetwork::gjCallTemplate']]]
];
