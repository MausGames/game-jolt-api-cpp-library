var searchData=
[
  ['removecall_332',['RemoveCall',['../classgj_data_item.html#ae35a5f2447345d3984844da5a65223da',1,'gjDataItem::RemoveCall()'],['../classgj_data_item.html#a4ab47691b87a414e4a837d1acd732c16',1,'gjDataItem::RemoveCall(GJ_NETWORK_OUTPUT(gjDataItemPtr))']]],
  ['removenow_333',['RemoveNow',['../classgj_data_item.html#a43f4827f3eccc13fb0f92142ca8d722d',1,'gjDataItem']]]
];
